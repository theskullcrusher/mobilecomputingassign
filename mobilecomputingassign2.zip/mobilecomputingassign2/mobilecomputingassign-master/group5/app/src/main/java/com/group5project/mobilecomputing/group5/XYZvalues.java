package com.group5project.mobilecomputing.group5;

public class XYZvalues {
    public float x_value;
    public float y_value;
    public float z_value;
}
